<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Home
$route['home'] = 'Home/index';

// Movies
$route['movies'] = 'Movies/index';
$route['movies/detail/(:num)'] = 'Movies/detail/$1';

// Booking
$route['booking/seats'] = 'Booking/seats';
$route['booking/payment'] = 'Booking/payment';
$route['booking/process'] = 'Booking/process';
$route['booking/confirmation'] = 'Booking/confirmation';
$route['booking/my_bookings'] = 'Booking/my_bookings';
$route['booking/get_booked_seats'] = 'Booking/get_booked_seats';
$route['booking/download/(:any)'] = 'Booking/download/$1';

// Auth
$route['auth/login'] = 'Auth/login';
$route['auth/do_login'] = 'Auth/do_login';
$route['auth/logout'] = 'Auth/logout';