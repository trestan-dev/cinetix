<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('session');
        $this->load->helper('url');
    }

    public function login() {
        // Show login modal via AJAX response or redirect home with modal flag
        redirect(base_url());
    }

    public function do_login() {
        $email    = $this->input->post('email');
        $password = $this->input->post('password');

        if (!$email || !$password) {
            echo json_encode(['success' => false, 'message' => 'Please fill in all fields.']);
            return;
        }

        $user = $this->User_model->get_user_by_email($email);

        if ($user && $this->User_model->verify_password($password, $user->password)) {
            $this->session->set_userdata([
                'user_id'    => $user->id,
                'user_email' => $user->email,
                'user_name'  => $user->name,
                'logged_in'  => TRUE,
            ]);
            echo json_encode(['success' => true, 'name' => $user->name ?: explode('@', $email)[0]]);
        } else {
            // Demo mode: auto-login with email
            $name = explode('@', $email)[0];
            $this->session->set_userdata([
                'user_email' => $email,
                'user_name'  => $name,
                'logged_in'  => TRUE,
            ]);
            echo json_encode(['success' => true, 'name' => $name]);
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url());
    }
}
