<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(['Movie_model', 'Booking_model']);
        $this->load->helper(['url', 'html']);
        $this->load->library('session');
    }

    // GET /booking/seats?movie_id=&date=&showtime=
    public function seats() {
        $movie_id = $this->input->get('movie_id');
        $date     = $this->input->get('date');
        $showtime = $this->input->get('showtime');

        if (!$movie_id || !$date || !$showtime) {
            redirect(base_url());
        }

        $data['movie']    = $this->Movie_model->get_movie($movie_id);
        $data['date']     = $date;
        $data['showtime'] = $showtime;
        $data['booked']   = $this->Booking_model->get_booked_seats($movie_id, $date, $showtime);

        // Store in session for payment step
        $this->session->set_userdata([
            'booking_movie_id' => $movie_id,
            'booking_date'     => $date,
            'booking_showtime' => $showtime,
        ]);

        $this->load->view('layouts/header', $data);
        $this->load->view('booking/seats', $data);
        $this->load->view('layouts/footer');
    }

    // AJAX: GET /booking/get_booked_seats?movie_id=&date=&showtime=
    public function get_booked_seats() {
        $movie_id = $this->input->get('movie_id');
        $date     = $this->input->get('date');
        $showtime = $this->input->get('showtime');
        $booked   = $this->Booking_model->get_booked_seats($movie_id, $date, $showtime);
        echo json_encode($booked);
    }

    // POST /booking/payment
    public function payment() {
        $seats = $this->input->post('seats');
        if (!$seats) {
            redirect(base_url('booking/seats'));
        }

        $movie_id = $this->session->userdata('booking_movie_id');
        $date     = $this->session->userdata('booking_date');
        $showtime = $this->session->userdata('booking_showtime');

        $seat_arr = explode(',', $seats);
        $n        = count($seat_arr);
        $subtotal = $n * 250;
        $total    = $subtotal + 20;

        $data['movie']    = $this->Movie_model->get_movie($movie_id);
        $data['date']     = $date;
        $data['showtime'] = $showtime;
        $data['seats']    = $seat_arr;
        $data['subtotal'] = $subtotal;
        $data['total']    = $total;

        $this->session->set_userdata('booking_seats', $seats);

        $this->load->view('layouts/header', $data);
        $this->load->view('booking/payment', $data);
        $this->load->view('layouts/footer');
    }

    // POST /booking/process
    public function process() {
        $method = $this->input->post('method');
        
        // Get payment details based on method
        if ($method === 'card') {
            $name   = $this->input->post('name');
            $card   = $this->input->post('card');
            $expiry = $this->input->post('expiry');
            $cvv    = $this->input->post('cvv');

            if (!$name || !$card || !$expiry || !$cvv) {
                $this->session->set_flashdata('error', 'Please fill in all payment details.');
                redirect(base_url('booking/payment'));
            }
            
            $card_clean = preg_replace('/\s/', '', $card);
            $last4      = substr($card_clean, -4);
            $payment_detail = 'Card: **** ' . $last4;
        } elseif ($method === 'gcash') {
            $gcash_number = $this->input->post('gcash_number');
            $gcash_name   = $this->input->post('gcash_name');

            if (!$gcash_number || !$gcash_name) {
                $this->session->set_flashdata('error', 'Please fill in GCash details.');
                redirect(base_url('booking/payment'));
            }
            
            $last4 = substr($gcash_number, -4);
            $payment_detail = 'GCash: **** ' . $last4;
            $name = $gcash_name;
        } elseif ($method === 'maya') {
            $maya_number = $this->input->post('maya_number');
            $maya_name   = $this->input->post('maya_name');

            if (!$maya_number || !$maya_name) {
                $this->session->set_flashdata('error', 'Please fill in Maya details.');
                redirect(base_url('booking/payment'));
            }
            
            $last4 = substr($maya_number, -4);
            $payment_detail = 'Maya: **** ' . $last4;
            $name = $maya_name;
        } else {
            $this->session->set_flashdata('error', 'Invalid payment method.');
            redirect(base_url('booking/payment'));
        }

        $movie_id = $this->session->userdata('booking_movie_id');
        $date     = $this->session->userdata('booking_date');
        $showtime = $this->session->userdata('booking_showtime');
        $seats    = $this->session->userdata('booking_seats');

        $seat_arr   = explode(',', $seats);
        $n          = count($seat_arr);
        $amount     = ($n * 250) + 20;
        $ticket_id  = 'TIX-' . time() . rand(100, 999);

        // Save booking
        $this->Booking_model->save_booking([
            'ticket_id'    => $ticket_id,
            'user_name'    => $name,
            'movie_id'     => $movie_id,
            'booking_date' => $date,
            'showtime'     => $showtime,
            'cinema'       => 'Cinema 2',
            'seats'        => $seats,
            'amount'       => $amount,
            'card_last4'   => $last4,
            'payment_method' => $method,
            'status'       => 'confirmed',
        ]);

        // Mark seats as booked
        $this->Booking_model->save_booked_seats($movie_id, $date, $showtime, $seat_arr);

        // Clear session booking data
        $this->session->unset_userdata(['booking_seats']);

        // Store ticket_id for confirmation page
        $this->session->set_userdata('last_ticket_id', $ticket_id);

        redirect(base_url('booking/confirmation'));
    }

    // GET /booking/confirmation
    public function confirmation() {
        $ticket_id = $this->session->userdata('last_ticket_id');
        if (!$ticket_id) redirect(base_url());

        $booking = $this->Booking_model->get_booking_by_ticket($ticket_id);
        $movie   = $this->Movie_model->get_movie($booking->movie_id);

        $data['booking'] = $booking;
        $data['movie']   = $movie;

        $this->load->view('layouts/header', $data);
        $this->load->view('booking/confirmation', $data);
        $this->load->view('layouts/footer');
    }

    // GET /booking/my_bookings
    public function my_bookings() {
        $data['bookings'] = $this->Booking_model->get_all_bookings();
        // Attach movie info
        foreach ($data['bookings'] as &$b) {
            $b->movie = $this->Movie_model->get_movie($b->movie_id);
        }
        $this->load->view('layouts/header', $data);
        $this->load->view('booking/my_bookings', $data);
        $this->load->view('layouts/footer');
    }

    // GET /booking/download/:ticket_id
    public function download($ticket_id) {
        $booking = $this->Booking_model->get_booking_by_ticket($ticket_id);
        if (!$booking) show_404();
        $movie = $this->Movie_model->get_movie($booking->movie_id);

        $date_label = date('F j, Y', strtotime($booking->booking_date));
        $content  = "CINETIX – BOOKING CONFIRMATION\n";
        $content .= "==============================\n";
        $content .= "Ticket ID  : {$booking->ticket_id}\n";
        $content .= "Movie      : {$movie->title}\n";
        $content .= "Date       : {$date_label}\n";
        $content .= "Time       : {$booking->showtime}\n";
        $content .= "Cinema     : {$booking->cinema}\n";
        $content .= "Seats      : {$booking->seats}\n";
        $content .= "Amount     : ₱" . number_format($booking->amount) . ".00\n";
        $content .= "Cardholder : {$booking->user_name}\n";
        $content .= "Card       : **** **** **** {$booking->card_last4}\n";
        $content .= "Status     : CONFIRMED\n";
        $content .= "Booked At  : {$booking->booked_at}\n";
        $content .= "==============================\n";
        $content .= "Thank you for choosing CINETIX!\n";

        $this->load->helper('download');
        force_download("CINETIX-{$ticket_id}.txt", $content);
    }
}
