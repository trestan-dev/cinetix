<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Movie_model');
        $this->load->helper(['url', 'html']);
    }

    public function index() {
        $data['now_showing'] = $this->Movie_model->get_now_showing(5);
        $data['coming_soon'] = $this->Movie_model->get_coming_soon();
        $this->load->view('layouts/header', $data);
        $this->load->view('home/index', $data);
        $this->load->view('layouts/footer');
    }
}
