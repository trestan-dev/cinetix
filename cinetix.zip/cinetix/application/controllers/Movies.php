<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Movies extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Movie_model');
        $this->load->helper(['url', 'html']);
    }

    public function index() {
        $data['movies'] = $this->Movie_model->get_all_movies();
        $this->load->view('layouts/header', $data);
        $this->load->view('movies/index', $data);
        $this->load->view('layouts/footer');
    }

    public function detail($id) {
        $data['movie']     = $this->Movie_model->get_movie($id);
        if (!$data['movie']) redirect(base_url());
        $data['showtimes'] = $this->Movie_model->get_showtimes($id);
        $this->load->view('layouts/header', $data);
        $this->load->view('movies/detail', $data);
        $this->load->view('layouts/footer');
    }
}
