<?php
defined('BASEPATH') OR exit('No direct script access allowed');

#[AllowDynamicProperties]
class MY_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    protected function session_user() {
        return $this->session->userdata('user');
    }

    protected function set_session($user) {
        $this->session->set_userdata('user', [
            'id'         => $user['id'],
            'role'       => $user['role'],
            'name'       => trim($user['first_name'] . ' ' . $user['last_name']),
            'email'      => $user['email'],
            'first_name' => $user['first_name'],
            'last_name'  => $user['last_name'],
        ]);
    }
}
