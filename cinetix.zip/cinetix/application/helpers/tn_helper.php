    <?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    /**
     * Require a logged-in user with a specific role.
     * Redirects to signin if not authenticated.
     */
    function require_auth($role = null) {
        $CI =& get_instance();
        $user = $CI->session->userdata('user');
        if (!$user) {
            redirect('signin');
            exit;
        }
        if ($role && $user['role'] !== $role) {
            $CI->session->sess_destroy();
            redirect('signin');
            exit;
        }
        return $user;
    }

    /**
     * Output a JSON success response and stop execution.
     */
    function json_success($data = array(), $message = 'OK') {
        $CI =& get_instance();
        $CI->output->set_content_type('application/json');
        $CI->output->set_output(json_encode([
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ]));
        $CI->output->_display();
        exit;
    }

    /**
     * Output a JSON error response and stop execution.
     */
    function json_error($message = 'Error') {
        $CI =& get_instance();
        $CI->output->set_content_type('application/json');
        $CI->output->set_output(json_encode([
            'success' => false,
            'message' => $message,
            'data'    => [],
        ]));
        $CI->output->_display();
        exit;
    }

    /**
     * Format a date string for display.
     */
    function fmt_date($date) {
        if (!$date || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') return '—';
        return date('M j, Y', strtotime($date));
    }

    /**
     * Generate a unique application code like APP-342-007
     */
    function gen_app_code($count) {
        $rand = rand(100, 999);
        return 'APP-' . $rand . '-' . str_pad($count + 1, 3, '0', STR_PAD_LEFT);
    }

    /**
     * Format a date + time string for display.
     */
    function fmt_datetime($date) {
        if (!$date || $date === '0000-00-00 00:00:00') return '—';
        return date('M j, Y g:i A', strtotime($date));
    }