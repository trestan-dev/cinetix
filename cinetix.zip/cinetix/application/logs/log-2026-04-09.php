<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\tncompany\system\core\URI.php 102
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 397
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 303
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 328
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 355
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 365
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 366
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 367
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 368
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 426
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 110
ERROR - 2026-04-09 01:40:21 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 137
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 1284
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property Home::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 359
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:40:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\tncompany\system\core\URI.php 102
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 397
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 303
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 328
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 355
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 365
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 366
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 367
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 368
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 426
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 110
ERROR - 2026-04-09 01:41:43 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 137
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 1284
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property Home::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 359
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:41:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\tncompany\system\core\URI.php 102
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Controller.php 83
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 397
ERROR - 2026-04-09 01:44:32 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 303
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 328
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 355
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 365
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 366
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 367
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 368
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 426
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 110
ERROR - 2026-04-09 01:44:33 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\tncompany\system\libraries\Session\Session.php 137
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 1284
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property Home::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 359
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:44:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\tncompany\system\core\URI.php 102
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:46:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:45 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\tncompany\system\core\URI.php 102
ERROR - 2026-04-09 01:47:45 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\tncompany\system\core\URI.php 102
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:46 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\tncompany\system\core\URI.php 102
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:47:51 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Router.php 128
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:48:52 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\tncompany\system\database\DB_driver.php 372
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 01:49:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Job_model is deprecated C:\xampp\htdocs\tncompany\system\core\Loader.php 932
ERROR - 2026-04-09 02:50:41 --> 404 Page Not Found: Public/index
ERROR - 2026-04-09 10:45:39 --> The upload path does not appear to be valid.
ERROR - 2026-04-09 10:45:47 --> The upload path does not appear to be valid.
ERROR - 2026-04-09 10:47:15 --> The upload path does not appear to be valid.
ERROR - 2026-04-09 10:49:05 --> The upload path does not appear to be valid.
