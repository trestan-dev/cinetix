<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:15:27 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:15:27 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:15:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:16:38 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:16:38 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:16:38 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:18:10 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:18:10 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:18:10 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:10 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:18:11 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:18:11 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:18:11 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:18:11 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:18:11 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:18:11 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:18:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:21:10 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:21:10 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:21:10 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\xampp\htdocs\cinetix\system\core\Controller.php 83
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 399
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 303
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 328
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 355
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 365
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 366
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 367
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 368
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 426
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 110
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\cinetix\system\libraries\Session\Session.php 137
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 1286
ERROR - 2026-04-24 04:21:19 --> Severity: 8192 --> Creation of dynamic property Home::$Movie_model is deprecated C:\xampp\htdocs\cinetix\system\core\Loader.php 361
ERROR - 2026-04-24 04:21:19 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cinetix\system\core\Exceptions.php:272) C:\xampp\htdocs\cinetix\system\core\Common.php 571
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> include(C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:21:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\cinetix\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\cinetix\system\core\Exceptions.php 183
ERROR - 2026-04-24 04:23:45 --> Query error: Table 'tn_registration_db.movies' doesn't exist - Invalid query: SELECT *
FROM `movies`
WHERE `status` = 'now'
 LIMIT 5
