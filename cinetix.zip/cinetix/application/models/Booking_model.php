<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking_model extends CI_Model {

    public function get_booked_seats($movie_id, $date, $showtime) {
        $this->db->select('seat_code');
        $this->db->where('movie_id', $movie_id);
        $this->db->where('booking_date', $date);
        $this->db->where('showtime', $showtime);
        $rows = $this->db->get('booked_seats')->result();
        return array_column($rows, 'seat_code');
    }

    public function save_booking($data) {
        return $this->db->insert('bookings', $data);
    }

    public function save_booked_seats($movie_id, $date, $showtime, $seats) {
        foreach ($seats as $seat) {
            $this->db->replace('booked_seats', [
                'movie_id'     => $movie_id,
                'booking_date' => $date,
                'showtime'     => $showtime,
                'seat_code'    => $seat,
            ]);
        }
    }

    public function get_booking_by_ticket($ticket_id) {
        return $this->db->get_where('bookings', ['ticket_id' => $ticket_id])->row();
    }

    public function get_all_bookings() {
        $this->db->order_by('booked_at', 'DESC');
        return $this->db->get('bookings')->result();
    }
}
