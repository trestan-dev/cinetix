<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Movie_model extends CI_Model {

    public function get_now_showing($limit = NULL) {
        $this->db->where('status', 'now');
        if ($limit) $this->db->limit($limit);
        return $this->db->get('movies')->result();
    }

    public function get_coming_soon() {
        $this->db->where('status', 'coming');
        return $this->db->get('movies')->result();
    }

    public function get_all_movies() {
        return $this->db->get('movies')->result();
    }

    public function get_movie($id) {
        return $this->db->get_where('movies', ['id' => $id])->row();
    }

    public function get_showtimes($movie_id) {
        $this->db->where('movie_id', $movie_id);
        return $this->db->get('showtimes')->result();
    }
}
