<?php
$date_label  = date('F j, Y', strtotime($booking->booking_date));
$seat_list   = htmlspecialchars($booking->seats);
$ticket_id   = htmlspecialchars($booking->ticket_id);
$payment_method = isset($booking->payment_method) ? $booking->payment_method : 'card';

// Payment method logos (using text/emoji as placeholder - replace with actual images if available)
$payment_logos = [
    'card' => [
        'name' => 'Credit / Debit Card',
        'icon' => '<i class="bi bi-credit-card" style="font-size: 2.5rem; color: #1a1a2e;"></i>'
    ],
    'gcash' => [
        'name' => 'GCash',
        'icon' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="24" fill="#0075e3"/><text x="24" y="30" text-anchor="middle" fill="white" font-size="20" font-weight="bold">G</text></svg>'
    ],
    'maya' => [
        'name' => 'Maya',
        'icon' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="24" fill="#be3cca"/><text x="24" y="30" text-anchor="middle" fill="white" font-size="20" font-weight="bold">M</text></svg>'
    ]
];

$current_payment = isset($payment_logos[$payment_method]) ? $payment_logos[$payment_method] : $payment_logos['card'];
?>
<div class="container section-pad">
  <div class="confirmation-card">
    <div class="check-circle"><i class="bi bi-check-lg"></i></div>
    <h5 style="font-weight:700;margin-bottom:6px">Booking Confirmed!</h5>
    <p style="color:var(--text-muted);font-size:0.9rem;margin-bottom:24px">Your ticket has been booked successfully.</p>

    <!-- Payment Method Logo -->
    <div class="ticket-qr" id="payment-logo" style="padding: 20px; background: #f8f9fa; border-radius: 12px; display: inline-block;">
      <?= $current_payment['icon'] ?>
      <div style="margin-top: 8px; font-size: 0.85rem; color: #666;"><?= $current_payment['name'] ?></div>
    </div>

    <!-- Ticket Details -->
    <div style="text-align:left;margin-top:20px">
      <div class="ticket-detail-row"><span class="ticket-detail-label">Ticket ID</span><span style="font-weight:500"><?= $ticket_id ?></span></div>
      <div class="ticket-detail-row"><span class="ticket-detail-label">Movie</span><span style="font-weight:500"><?= htmlspecialchars($movie->title) ?></span></div>
      <div class="ticket-detail-row"><span class="ticket-detail-label">Date</span><span style="font-weight:500"><?= $date_label ?></span></div>
      <div class="ticket-detail-row"><span class="ticket-detail-label">Time</span><span style="font-weight:500"><?= htmlspecialchars($booking->showtime) ?></span></div>
      <div class="ticket-detail-row"><span class="ticket-detail-label">Cinema</span><span style="font-weight:500"><?= htmlspecialchars($booking->cinema) ?></span></div>
      <div class="ticket-detail-row"><span class="ticket-detail-label">Seats</span><span style="font-weight:500"><?= $seat_list ?></span></div>
      <div class="ticket-detail-row"><span class="ticket-detail-label">Amount Paid</span><span style="font-weight:500">₱<?= number_format($booking->amount) ?>.00</span></div>
    </div>

    <div class="d-flex gap-3 mt-4 justify-content-center flex-wrap">
      <a href="<?= base_url('booking/download/'.urlencode($booking->ticket_id)) ?>" class="btn-outline-accent">
        <i class="bi bi-download me-1"></i>Download Ticket
      </a>
      <a href="<?= base_url('booking/my_bookings') ?>" class="btn-accent">Go to My Bookings</a>
    </div>
  </div>
</div>

<?php /* QR code script removed - using payment method logo instead */ ?>
