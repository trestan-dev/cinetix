<div class="container section-pad">
  <h5 style="font-weight:700;margin-bottom:24px">My Bookings</h5>

  <?php if (empty($bookings)): ?>
    <div class="empty-state">
      <i class="bi bi-ticket-perforated"></i>
      <p>No bookings yet.</p>
      <a href="<?= base_url() ?>" class="btn-accent mt-3" style="display:inline-block">Browse Movies</a>
    </div>
  <?php else: ?>
    <?php foreach ($bookings as $b): ?>
      <?php $date_label = date('F j, Y', strtotime($b->booking_date)); ?>
      <div class="booking-item">
        <img src="<?= htmlspecialchars($b->movie->poster) ?>" alt="<?= htmlspecialchars($b->movie->title) ?>"
             class="booking-poster"
             onerror="this.src='https://via.placeholder.com/60x90/13131a/e8003d?text=C'">
        <div class="flex-grow-1">
          <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
            <div>
              <div style="font-weight:600;font-size:1rem"><?= htmlspecialchars($b->movie->title) ?></div>
              <div style="color:var(--text-muted);font-size:0.82rem;margin-top:4px">
                <i class="bi bi-calendar3 me-1"></i><?= $date_label ?>
                &nbsp;<i class="bi bi-clock me-1"></i><?= htmlspecialchars($b->showtime) ?>
                &nbsp;<i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($b->cinema) ?>
              </div>
              <div style="color:var(--text-muted);font-size:0.82rem;margin-top:3px">
                <i class="bi bi-ticket me-1"></i>Seats: <?= htmlspecialchars($b->seats) ?>
              </div>
            </div>
            <div class="text-end">
              <span class="booking-badge confirmed">Confirmed</span>
              <div style="font-weight:700;color:var(--accent);margin-top:6px">₱<?= number_format($b->amount) ?>.00</div>
              <div style="font-size:0.75rem;color:var(--text-muted)"><?= htmlspecialchars($b->ticket_id) ?></div>
              <a href="<?= base_url('booking/download/'.urlencode($b->ticket_id)) ?>"
                 class="btn-outline-accent mt-2"
                 style="font-size:0.78rem;padding:4px 12px;display:inline-block">
                <i class="bi bi-download me-1"></i>Download
              </a>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
