<div class="container section-pad">
  <a href="<?= base_url('booking/seats?movie_id='.$movie->id.'&date='.urlencode($date).'&showtime='.urlencode($showtime)) ?>" class="back-btn">
    <i class="bi bi-arrow-left"></i> Back
  </a>

  <div class="row g-4">
    <div class="col-lg-7">
      <div class="payment-card">
        <h6 class="mb-4" style="font-weight:600">Payment</h6>

        <form action="<?= base_url('booking/process') ?>" method="post" id="pay-form">
          <input type="hidden" name="<?= $this->security->get_csrf_token_name() ?>" value="<?= $this->security->get_csrf_hash() ?>">

          <div class="mb-3">
            <label class="form-label-custom">Payment Method</label>
            <select class="form-select-custom" name="method" id="payment-method" onchange="togglePaymentFields()">
              <option value="card">Credit / Debit Card</option>
              <option value="gcash">GCash</option>
              <option value="maya">Maya</option>
            </select>
          </div>

          <!-- Card fields (for Credit/Debit) -->
          <div id="card-fields">
            <div class="mb-3">
              <label class="form-label-custom">Card Number</label>
              <input class="form-input" name="card" id="pay-card" placeholder="1234 5678 9012 3456" maxlength="19">
            </div>
            <div class="row g-3 mb-3">
              <div class="col-6">
                <label class="form-label-custom">Expiry Date</label>
                <input class="form-input" name="expiry" id="pay-expiry" placeholder="MM / YY" maxlength="7">
              </div>
              <div class="col-6">
                <label class="form-label-custom">CVV</label>
                <input class="form-input" name="cvv" id="pay-cvv" placeholder="123" maxlength="3">
              </div>
            </div>
            <div class="mb-4">
              <label class="form-label-custom">Cardholder Name</label>
              <input class="form-input" name="name" id="pay-name" placeholder="JUAN DELA CRUZ">
            </div>
          </div>

          <!-- GCash fields -->
          <div id="gcash-fields" style="display:none">
            <div class="mb-3">
              <label class="form-label-custom">GCash Number</label>
              <input class="form-input" name="gcash_number" id="pay-gcash" placeholder="09XXXXXXXXX" maxlength="11">
            </div>
            <div class="mb-4">
              <label class="form-label-custom">GCash Name</label>
              <input class="form-input" name="gcash_name" id="pay-gcash-name" placeholder="JUAN DELA CRUZ">
            </div>
          </div>

          <!-- Maya fields -->
          <div id="maya-fields" style="display:none">
            <div class="mb-3">
              <label class="form-label-custom">Maya Number</label>
              <input class="form-input" name="maya_number" id="pay-maya" placeholder="09XXXXXXXXX" maxlength="11">
            </div>
            <div class="mb-4">
              <label class="form-label-custom">Maya Name</label>
              <input class="form-input" name="maya_name" id="pay-maya-name" placeholder="JUAN DELA CRUZ">
            </div>
          </div>

          <button type="submit" class="btn-accent w-100" id="pay-btn">
            Pay ₱<?= number_format($total) ?>.00
          </button>
        </form>
      </div>
    </div>

    <!-- Summary -->
    <div class="col-lg-5">
      <div class="summary-card">
        <div class="d-flex gap-3 mb-3">
          <img src="<?= htmlspecialchars($movie->poster) ?>" alt="" class="summary-poster"
               onerror="this.src='https://via.placeholder.com/60x90/13131a/e8003d?text=C'">
          <div>
            <div style="font-weight:600;font-size:0.95rem"><?= htmlspecialchars($movie->title) ?></div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              <i class="bi bi-calendar3 me-1"></i><?= date('F j, Y', strtotime($date)) ?>
            </div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              <i class="bi bi-clock me-1"></i><?= htmlspecialchars($showtime) ?>
            </div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              <i class="bi bi-geo-alt me-1"></i>Cinema 2
            </div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              Seats: <?= htmlspecialchars(implode(', ', $seats)) ?>
            </div>
          </div>
        </div>
        <hr class="summary-divider">
        <div class="price-row">
          <span style="color:var(--text-muted)">Ticket Price (<?= count($seats) ?> x ₱250.00)</span>
          <span>₱<?= number_format($subtotal) ?>.00</span>
        </div>
        <div class="price-row">
          <span style="color:var(--text-muted)">Convenience Fee</span><span>₱20.00</span>
        </div>
        <div class="price-row total">
          <span>Total Amount</span>
          <span class="total-amount">₱<?= number_format($total) ?>.00</span>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function togglePaymentFields() {
  const method = document.getElementById('payment-method').value;
  document.getElementById('card-fields').style.display = method === 'card' ? 'block' : 'none';
  document.getElementById('gcash-fields').style.display = method === 'gcash' ? 'block' : 'none';
  document.getElementById('maya-fields').style.display = method === 'maya' ? 'block' : 'none';
}

// Card number formatter
document.getElementById('pay-card').addEventListener('input', function(){
  let v = this.value.replace(/\D/g,'').substring(0,16);
  v = v.replace(/(.{4})/g,'$1 ').trim();
  this.value = v;
});
// Expiry formatter
document.getElementById('pay-expiry').addEventListener('input', function(){
  let v = this.value.replace(/\D/g,'').substring(0,4);
  if(v.length > 2) v = v.substring(0,2) + ' / ' + v.substring(2);
  this.value = v;
});
// GCash number formatter
document.getElementById('pay-gcash').addEventListener('input', function(){
  let v = this.value.replace(/\D/g,'').substring(0,11);
  this.value = v;
});
// Maya number formatter
document.getElementById('pay-maya').addEventListener('input', function(){
  let v = this.value.replace(/\D/g,'').substring(0,11);
  this.value = v;
});
// Validate before submit
document.getElementById('pay-form').addEventListener('submit', function(e){
  const method = document.getElementById('payment-method').value;
  
  if (method === 'card') {
    const name   = document.getElementById('pay-name').value.trim();
    const card   = document.getElementById('pay-card').value.replace(/\s/g,'');
    const expiry = document.getElementById('pay-expiry').value.trim();
    const cvv    = document.getElementById('pay-cvv').value.trim();
    if(!name || !card || !expiry || !cvv){ e.preventDefault(); showToast('Please fill in all payment details.'); return; }
    if(card.length < 16){ e.preventDefault(); showToast('Please enter a valid card number.'); return; }
  } else if (method === 'gcash') {
    const gcashNum = document.getElementById('pay-gcash').value.trim();
    const gcashName = document.getElementById('pay-gcash-name').value.trim();
    if(!gcashNum || !gcashName){ e.preventDefault(); showToast('Please fill in GCash details.'); return; }
    if(gcashNum.length < 11){ e.preventDefault(); showToast('Please enter a valid GCash number (11 digits).'); return; }
  } else if (method === 'maya') {
    const mayaNum = document.getElementById('pay-maya').value.trim();
    const mayaName = document.getElementById('pay-maya-name').value.trim();
    if(!mayaNum || !mayaName){ e.preventDefault(); showToast('Please fill in Maya details.'); return; }
    if(mayaNum.length < 11){ e.preventDefault(); showToast('Please enter a valid Maya number (11 digits).'); return; }
  }
  
  document.getElementById('pay-btn').textContent = 'Processing...';
  document.getElementById('pay-btn').disabled = true;
});
</script>
