<?php
$seat_rows    = ['A','B','C','D','E','F','G'];
$seats_per_row = 12;
$booked_arr   = $booked; // array of seat codes like ['A1','B3',...]
?>
<div class="container section-pad">
  <a href="<?= base_url('movies/detail/'.$movie->id) ?>" class="back-btn"><i class="bi bi-arrow-left"></i> Back</a>

  <div class="row g-4">
    <!-- Seat Map -->
    <div class="col-lg-8">
      <div class="seat-map-section">
        <h6 class="mb-4" style="font-weight:600">Select Your Seats</h6>
        <div class="screen-label">SCREEN</div>

        <?php foreach ($seat_rows as $row): ?>
        <div class="seat-row">
          <div class="row-label"><?= $row ?></div>
          <?php for ($c = 1; $c <= $seats_per_row; $c++): ?>
            <?php if ($c === 5 || $c === 9): ?>
              <div class="seat-gap"></div>
            <?php endif; ?>
            <?php
              $seatId   = $row . $c;
              $is_booked = in_array($seatId, $booked_arr);
            ?>
            <div class="seat <?= $is_booked ? 'booked' : '' ?>"
                 data-seat="<?= $seatId ?>"
                 <?= $is_booked ? '' : 'onclick="toggleSeat(this)"' ?>>
              <?= $c ?>
            </div>
          <?php endfor; ?>
        </div>
        <?php endforeach; ?>

        <div class="d-flex justify-content-center mt-4">
          <div class="seat-legend">
            <div class="legend-item"><div class="legend-dot" style="background:var(--seat-available);border:1px solid #3a3a4a"></div>Available</div>
            <div class="legend-item"><div class="legend-dot" style="background:var(--seat-selected)"></div>Selected</div>
            <div class="legend-item"><div class="legend-dot" style="background:var(--seat-booked)"></div>Booked</div>
          </div>
        </div>
      </div>

      <div class="d-flex justify-content-between align-items-center mt-3">
        <span style="font-size:0.9rem;color:var(--text-muted)">
          Selected: <strong id="selected-seats-label" style="color:var(--text-primary)">None</strong>
        </span>
        <button class="btn-accent" onclick="goToPayment()">Continue</button>
      </div>
    </div>

    <!-- Summary -->
    <div class="col-lg-4">
      <div class="summary-card">
        <div class="d-flex gap-3 mb-3">
          <img src="<?= htmlspecialchars($movie->poster) ?>" alt="" class="summary-poster"
               onerror="this.src='https://via.placeholder.com/60x90/13131a/e8003d?text=C'">
          <div>
            <div style="font-weight:600;font-size:0.95rem"><?= htmlspecialchars($movie->title) ?></div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              <i class="bi bi-calendar3 me-1"></i><?= date('F j, Y', strtotime($date)) ?>
            </div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              <i class="bi bi-clock me-1"></i><?= htmlspecialchars($showtime) ?>
            </div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              <i class="bi bi-geo-alt me-1"></i>Cinema 2
            </div>
            <div style="font-size:0.82rem;color:var(--text-muted)" class="mt-1">
              <i class="bi bi-ticket me-1"></i>Seats: <span id="summary-seats-label">—</span>
            </div>
          </div>
        </div>
        <hr class="summary-divider">
        <div class="price-row">
          <span style="color:var(--text-muted)">Ticket (<span id="seat-count">0</span> x ₱250.00)</span>
          <span id="ticket-subtotal">₱0.00</span>
        </div>
        <div class="price-row">
          <span style="color:var(--text-muted)">Convenience Fee</span><span>₱20.00</span>
        </div>
        <div class="price-row total">
          <span>Total</span><span class="total-amount" id="total-amount">₱20.00</span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Hidden form to POST seats to payment -->
<form id="payment-form" action="<?= base_url('booking/payment') ?>" method="post" style="display:none">
  <?= $this->security->get_csrf_token_name() ?>
  <input type="hidden" name="<?= $this->security->get_csrf_token_name() ?>" value="<?= $this->security->get_csrf_hash() ?>">
  <input type="hidden" name="seats" id="seats-input">
</form>

<script>
const TICKET_PRICE = 250;
const CONV_FEE     = 20;
let selectedSeats  = [];

function toggleSeat(el) {
  const id = el.dataset.seat;
  if (el.classList.contains('selected')) {
    el.classList.remove('selected');
    selectedSeats = selectedSeats.filter(s => s !== id);
  } else {
    if (selectedSeats.length >= 8) { showToast('Maximum 8 seats per booking.'); return; }
    el.classList.add('selected');
    selectedSeats.push(id);
  }
  updateSummary();
}

function updateSummary() {
  const n   = selectedSeats.length;
  const sub = n * TICKET_PRICE;
  const tot = sub + (n > 0 ? CONV_FEE : 0);
  const lbl = n > 0 ? selectedSeats.join(', ') : 'None';
  document.getElementById('selected-seats-label').textContent = lbl;
  document.getElementById('summary-seats-label').textContent  = lbl;
  document.getElementById('seat-count').textContent     = n;
  document.getElementById('ticket-subtotal').textContent = '₱' + sub.toLocaleString() + '.00';
  document.getElementById('total-amount').textContent    = '₱' + (n > 0 ? tot : CONV_FEE).toLocaleString() + '.00';
}

function goToPayment() {
  if (selectedSeats.length === 0) { showToast('Please select at least one seat.'); return; }
  document.getElementById('seats-input').value = selectedSeats.join(',');
  document.getElementById('payment-form').submit();
}
</script>
