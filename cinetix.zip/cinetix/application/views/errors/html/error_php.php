<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Application Error</title>
<style>
  body { background:#0a0a0f; color:#f0f0f5; font-family:'Segoe UI',sans-serif; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
  .error-box { background:#13131a; border:1px solid #2a2a38; border-radius:12px; padding:40px; max-width:600px; width:90%; }
  h1 { color:#e8003d; font-size:1.4rem; margin-bottom:16px; }
  p { color:#888899; font-size:0.9rem; line-height:1.6; margin-bottom:8px; }
  .msg { background:#1a1a24; border-left:3px solid #e8003d; padding:12px 16px; border-radius:4px; color:#f0f0f5; font-family:monospace; font-size:0.85rem; margin-top:16px; word-break:break-all; }
  a { color:#e8003d; }
</style>
</head>
<body>
<div class="error-box">
  <h1>&#9632; CINETIX — Application Error</h1>
  <p>A PHP error was encountered.</p>
  <?php if (isset($severity)): ?>
  <div class="msg">
    <strong>Severity:</strong> <?= htmlspecialchars($severity) ?><br>
    <strong>Message:</strong> <?= htmlspecialchars($message) ?><br>
    <strong>File:</strong> <?= htmlspecialchars($filepath) ?><br>
    <strong>Line:</strong> <?= htmlspecialchars($line) ?>
  </div>
  <?php endif; ?>
  <p style="margin-top:20px"><a href="javascript:history.back()">← Go Back</a></p>
</div>
</body>
</html>
 