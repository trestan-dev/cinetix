<!-- ══════════════════════ HERO ══════════════════════ -->
<div class="hero">
  <div class="hero-bg"></div>
  <div class="hero-overlay"></div>
  <div class="container hero-content py-5">
    <h1>Book Your<br><span>Movie Tickets</span> Easily</h1>
    <p>Choose your movie, select your seats, and enjoy the show!</p>
    <a href="#now-showing" class="btn-accent">Browse Movies</a>
  </div>
</div>

<!-- ══════════════════════ NOW SHOWING ══════════════════════ -->
<div class="container section-pad" id="now-showing">
  <div class="section-header">
    <span class="section-title">Now Showing</span>
    <a href="<?= base_url('movies') ?>" class="view-all">View All</a>
  </div>
  <div class="films-grid">
    <?php foreach ($now_showing as $m): ?>
    <a href="<?= base_url('movies/detail/'.$m->id) ?>" class="movie-card" style="text-decoration:none">
      <img src="<?= htmlspecialchars($m->poster) ?>" alt="<?= htmlspecialchars($m->title) ?>" class="movie-poster"
           onerror="this.src='https://via.placeholder.com/200x300/13131a/e8003d?text=CINETIX'">
      <div class="movie-info">
        <div class="movie-title"><?= htmlspecialchars($m->title) ?></div>
        <div class="movie-genre"><?= htmlspecialchars($m->genre) ?></div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- ══════════════════════ COMING SOON ══════════════════════ -->
<div class="container pb-5">
  <div class="section-header">
    <span class="section-title">Coming Soon</span>
  </div>
  <div class="films-grid">
    <?php foreach ($coming_soon as $m): ?>
    <a href="<?= base_url('movies/detail/'.$m->id) ?>" class="movie-card" style="text-decoration:none">
      <img src="<?= htmlspecialchars($m->poster) ?>" alt="<?= htmlspecialchars($m->title) ?>" class="movie-poster"
           onerror="this.src='https://via.placeholder.com/200x300/13131a/e8003d?text=CINETIX'">
      <div class="movie-info">
        <div class="movie-title"><?= htmlspecialchars($m->title) ?></div>
        <div class="movie-genre"><?= htmlspecialchars($m->genre) ?></div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</div>
