<!-- ══════════════════════ LOGIN MODAL ══════════════════════ -->
<div class="modal fade" id="loginModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="background:var(--bg-card);border:1px solid var(--border);color:var(--text-primary)">
      <div class="modal-header" style="border-color:var(--border)">
        <h5 class="modal-title" style="font-family:'Bebas Neue',cursive;letter-spacing:2px;font-size:1.5rem"><span style="color:var(--accent)">■</span> CINETIX</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-4">
        <div class="mb-3">
          <label class="form-label-custom">Email</label>
          <input class="form-input" placeholder="juan@example.com" id="login-email">
        </div>
        <div class="mb-4">
          <label class="form-label-custom">Password</label>
          <input class="form-input" type="password" placeholder="••••••••" id="login-pass">
        </div>
        <button class="btn-accent w-100" onclick="doLogin()">Sign In</button>
        <p style="text-align:center;color:var(--text-muted);font-size:0.85rem;margin-top:14px">Don't have an account? <span style="color:var(--accent);cursor:pointer">Sign Up</span></p>
      </div>
    </div>
  </div>
</div>

<!-- Toast container -->
<div class="toast-container" id="toast-container"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="<?= base_url('assets/js/cinetix.js') ?>"></script>
<script>
  const BASE_URL = '<?= base_url() ?>';
</script>
</body>
</html>
