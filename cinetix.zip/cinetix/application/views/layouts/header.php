<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CINETIX – Book Your Movie Tickets Easily</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= base_url('assets/css/cinetix.css') ?>" rel="stylesheet">
</head>
<body>

<!-- ══════════════════════ NAVBAR ══════════════════════ -->
<nav class="navbar-cinetix">
  <div class="container d-flex align-items-center justify-content-between">
    <a href="<?= base_url() ?>" class="navbar-brand"><span>■</span> CINETIX</a>
    <div class="d-flex align-items-center gap-2">
      <a href="<?= base_url() ?>" class="nav-link-custom <?= (uri_string()=='' || uri_string()=='home') ? 'active' : '' ?>">Movies</a>
      <a href="<?= base_url('booking/my_bookings') ?>" class="nav-link-custom <?= strpos(uri_string(),'my_bookings')!==false ? 'active' : '' ?>">My Bookings</a>
      <?php if ($this->session->userdata('logged_in')): ?>
        <span class="nav-link-custom" style="color:var(--text-primary)">
          <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($this->session->userdata('user_name')) ?>
        </span>
        <a href="<?= base_url('auth/logout') ?>" class="btn-login ms-2">Logout</a>
      <?php else: ?>
        <button class="btn-login ms-2" onclick="showLoginModal()">Login</button>
      <?php endif; ?>
    </div>
  </div>
</nav>

<!-- Flash messages -->
<?php if ($this->session->flashdata('error')): ?>
<div class="alert alert-danger alert-dismissible m-0" role="alert">
  <?= $this->session->flashdata('error') ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible m-0" role="alert">
  <?= $this->session->flashdata('success') ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
