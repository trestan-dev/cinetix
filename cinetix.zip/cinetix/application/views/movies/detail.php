<div class="detail-hero">
  <div class="container">
    <a href="<?= base_url() ?>" class="back-btn"><i class="bi bi-arrow-left"></i> Back</a>
    <div class="d-flex gap-4 flex-wrap">
      <img src="<?= htmlspecialchars($movie->poster) ?>" alt="<?= htmlspecialchars($movie->title) ?>" class="detail-poster"
           onerror="this.src='https://via.placeholder.com/200x300/13131a/e8003d?text=CINETIX'">
      <div class="flex-grow-1">
        <h2 style="font-weight:700;font-size:2rem"><?= htmlspecialchars($movie->title) ?></h2>
        <div class="detail-meta mt-2">
          <span class="detail-rating">
            <i class="bi bi-shield-check me-1" style="color:var(--accent)"></i><?= htmlspecialchars($movie->rating) ?>
          </span>
          <span class="genre-badge"><?= htmlspecialchars($movie->genre) ?></span>
          <span style="color:var(--text-muted);font-size:0.85rem">
            <i class="bi bi-clock me-1"></i><?= htmlspecialchars($movie->duration) ?>
          </span>
        </div>
        <p style="color:var(--text-muted);font-size:0.92rem;max-width:520px;line-height:1.6">
          <?= htmlspecialchars($movie->description) ?>
        </p>

        <!-- Booking Form -->
        <form action="<?= base_url('booking/seats') ?>" method="get" class="mt-4" id="book-form">
          <input type="hidden" name="movie_id" value="<?= $movie->id ?>">
          <div class="mb-3">
            <label class="form-label-custom">Date</label>
            <select class="date-select" name="date" id="date-select">
              <?php
                for ($i = 0; $i < 7; $i++) {
                  $ts    = strtotime("+$i days");
                  $val   = date('Y-m-d', $ts);
                  $label = date('M j, Y', $ts);
                  echo "<option value=\"$val\">$label</option>";
                }
              ?>
            </select>
          </div>
          <div class="mb-4">
            <label class="form-label-custom">Showtime</label>
            <div class="d-flex gap-2 flex-wrap" id="showtime-btns">
              <?php foreach ($showtimes as $i => $st): ?>
                <button type="button"
                  class="showtime-btn <?= $i === 2 ? 'active' : '' ?>"
                  data-time="<?= htmlspecialchars($st->show_time) ?>"
                  onclick="selectShowtime(this)">
                  <?= htmlspecialchars($st->show_time) ?>
                </button>
              <?php endforeach; ?>
            </div>
            <input type="hidden" name="showtime" id="showtime-val"
              value="<?= isset($showtimes[2]) ? htmlspecialchars($showtimes[2]->show_time) : (isset($showtimes[0]) ? htmlspecialchars($showtimes[0]->show_time) : '') ?>">
          </div>
          <button type="submit" class="btn-accent">Book Now</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
function selectShowtime(el) {
  document.querySelectorAll('.showtime-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('showtime-val').value = el.dataset.time;
}
</script>
