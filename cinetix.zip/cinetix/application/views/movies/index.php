<div class="container section-pad">
  <a href="<?= base_url() ?>" class="back-btn"><i class="bi bi-arrow-left"></i> Back</a>
  <h5 class="mb-4" style="font-weight:600">All Movies</h5>
  <div class="films-grid">
    <?php foreach ($movies as $m): ?>
    <a href="<?= base_url('movies/detail/'.$m->id) ?>" class="movie-card" style="text-decoration:none">
      <img src="<?= htmlspecialchars($m->poster) ?>" alt="<?= htmlspecialchars($m->title) ?>" class="movie-poster"
           onerror="this.src='https://via.placeholder.com/200x300/13131a/e8003d?text=CINETIX'">
      <div class="movie-info">
        <div class="movie-title"><?= htmlspecialchars($m->title) ?></div>
        <div class="movie-genre"><?= htmlspecialchars($m->genre) ?></div>
        <?php if ($m->status === 'coming'): ?>
          <span class="genre-badge mt-1">Coming Soon</span>
        <?php endif; ?>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</div>
