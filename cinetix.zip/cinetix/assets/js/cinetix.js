// ══════════════════════════════════════════════
//  CINETIX — Shared JS (cinetix.js)
// ══════════════════════════════════════════════

// ── TOAST ──
function showToast(msg) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = 'cinetix-toast';
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.transition = 'opacity 0.3s';
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── LOGIN MODAL ──
function showLoginModal() {
  const modal = new bootstrap.Modal(document.getElementById('loginModal'));
  modal.show();
}

function doLogin() {
  const email = document.getElementById('login-email').value.trim();
  const pass  = document.getElementById('login-pass').value.trim();

  if (!email) { showToast('Please enter your email.'); return; }

  fetch(BASE_URL + 'auth/do_login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'email=' + encodeURIComponent(email) + '&password=' + encodeURIComponent(pass)
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      bootstrap.Modal.getInstance(document.getElementById('loginModal')).hide();
      showToast('Welcome back, ' + data.name + '! 🎬');
      setTimeout(() => location.reload(), 1000);
    } else {
      showToast(data.message || 'Login failed.');
    }
  })
  .catch(() => showToast('Something went wrong.'));
}

// ── SMOOTH SCROLL for hero button ──
document.addEventListener('DOMContentLoaded', function () {
  const heroBtn = document.querySelector('.hero .btn-accent');
  if (heroBtn) {
    heroBtn.addEventListener('click', function (e) {
      const target = document.getElementById('now-showing');
      if (target) {
        e.preventDefault();
        window.scrollTo({ top: target.offsetTop - 80, behavior: 'smooth' });
      }
    });
  }
});
